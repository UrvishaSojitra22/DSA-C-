#include <iostream>
using namespace std;

int main() {
    int start = 41; 
    int rows = 5;   

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j <= i; j++) {
            cout << start + j << " ";
        }
        cout << endl;
    }

    
}
